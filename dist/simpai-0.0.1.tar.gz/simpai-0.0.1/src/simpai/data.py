import numpy as np
from PIL import Image
import random

def filepath_to_ndarray(
    filepath:str,
    dtype:str           = 'float32',
    enhancement_enable  = True,        # 是否做数据增强（总开关）
    resize_enable:bool  = True,         # Resize
    resize_shape:tuple  = (500, 500),
    crop_enable:bool    = True,         # 随机裁剪
    crop_patch_size:int = 96,
    flip_lr_enable:bool = True,         # 左右翻转
    flip_lr_prob:float  = 0.5,
    flip_ud_enable:bool = True,         # 上下翻转
    flip_ud_prob:float  = 0.5,
    rot_enable:bool     = True,         # 旋转
    rot_prob:float      = 0.5,
    transpose:str       = 'hwc'         # 转换成什么形状
) -> np.ndarray:
    img = Image.open(filepath).convert('RGB')

    if resize_enable and enhancement_enable:
        img = img.resize(resize_shape)
    w, h = img.size
    if crop_enable and enhancement_enable:
        x = random.randint(0, w - crop_patch_size)
        y = random.randint(0, h - crop_patch_size)
        img = img.crop((x, y, x + crop_patch_size, y + crop_patch_size))

    img = np.array(img, dtype = dtype) / 255.0

    if enhancement_enable:
        if flip_lr_enable and random.random() < flip_lr_prob:
            img = np.fliplr(img)
        if flip_ud_enable and random.random() < flip_ud_prob:
            img = np.flipud(img)
        if rot_enable and random.random() < rot_prob:
            img = np.rot90(img, random.randint(1, 3))

    if transpose == 'hwc':
        pass
    elif transpose == 'chw':
        img = np.transpose(img, (2, 0, 1))

    # Make sure that the memory is continuous
    return np.ascontiguousarray(img)
